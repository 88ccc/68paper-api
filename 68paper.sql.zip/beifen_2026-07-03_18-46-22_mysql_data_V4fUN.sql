-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: beifen
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pt_admin`
--

DROP TABLE IF EXISTS `pt_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '昵称',
  `email` varchar(60) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `pass` varchar(100) NOT NULL,
  `openid` varchar(128) DEFAULT NULL COMMENT '微信公众号',
  `status` tinyint(3) unsigned DEFAULT '1' COMMENT '0待激活,1正常,2冻结',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `tips` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_admin`
--

LOCK TABLES `pt_admin` WRITE;
/*!40000 ALTER TABLE `pt_admin` DISABLE KEYS */;
INSERT INTO `pt_admin` VALUES (1,'admin',NULL,NULL,NULL,'e10adc3949ba59abbe56e057f20f883e',NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pt_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_article`
--

DROP TABLE IF EXISTS `pt_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_article` (
  `id` varchar(64) NOT NULL,
  `title` varchar(256) DEFAULT NULL COMMENT '标题',
  `content` text COMMENT '内容',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_article`
--

LOCK TABLES `pt_article` WRITE;
/*!40000 ALTER TABLE `pt_article` DISABLE KEYS */;
INSERT INTO `pt_article` VALUES ('notice',NULL,'<p>这是代理公告</p>','2026-06-15 20:02:23');
/*!40000 ALTER TABLE `pt_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_attach`
--

DROP TABLE IF EXISTS `pt_attach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_attach` (
  `userid` int(11) NOT NULL COMMENT '用户ID',
  `file_name` varchar(200) DEFAULT NULL COMMENT '附件名称',
  `file_path` varchar(200) DEFAULT NULL COMMENT '附件路径',
  `file_time` datetime DEFAULT NULL COMMENT '附件时间',
  `file_status` int(11) DEFAULT '0' COMMENT '状态,0=未上传,1=已上传代审核,2=审核通过,3=审核失败,4=永久禁用',
  `update_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='附件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_attach`
--

LOCK TABLES `pt_attach` WRITE;
/*!40000 ALTER TABLE `pt_attach` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_attach` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_balance`
--

DROP TABLE IF EXISTS `pt_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_balance` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `user_id` int(20) unsigned NOT NULL COMMENT '用户ID（关联用户表主键）',
  `before_balance` int(11) NOT NULL DEFAULT '0' COMMENT '变动前余额',
  `change_amount` int(11) NOT NULL COMMENT '变动金额（正数=增加，负数=减少）',
  `after_balance` int(11) NOT NULL DEFAULT '0' COMMENT '变动后余额',
  `change_type` tinyint(4) NOT NULL COMMENT '变更类型 1=充值，2=消费，3=退款，4=赠送，5=提现，6=其他',
  `business_no` varchar(128) DEFAULT '' COMMENT '关联业务单号（如订单号、充值单号、提现单号等）',
  `operator_id` int(11) DEFAULT '0' COMMENT '操作人ID（0=系统自动操作）',
  `operator_type` tinyint(4) DEFAULT '1' COMMENT '操作人类型：1=系统，2=管理员，3=用户自身',
  `remark` varchar(255) DEFAULT '' COMMENT '变动备注（如：微信充值、购买商品ID:123、退款原因：商品质量问题）',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（变动时间）',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`) COMMENT '用户ID索引，便于查询单个用户的余额变动记录',
  KEY `idx_create_time` (`create_time`) COMMENT '创建时间索引，便于按时间范围查询',
  KEY `idx_business_no` (`business_no`) COMMENT '业务单号索引，便于关联业务查询'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户余额变动记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_balance`
--

LOCK TABLES `pt_balance` WRITE;
/*!40000 ALTER TABLE `pt_balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_card`
--

DROP TABLE IF EXISTS `pt_card`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_card` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `userid` int(11) NOT NULL COMMENT '用户ID',
  `piece` int(11) NOT NULL COMMENT '件数',
  `used` int(11) NOT NULL COMMENT '已使用',
  `product_id` varchar(64) DEFAULT NULL COMMENT '产品ID',
  `order_id` varchar(64) DEFAULT NULL COMMENT '订单ID',
  `uuid` varchar(64) DEFAULT NULL COMMENT '调用方ID',
  `status` tinyint(4) NOT NULL COMMENT '状态：1=创建，2=已使用，3=禁用',
  `remark` varchar(255) DEFAULT '' COMMENT '备注',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='检测卡';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_card`
--

LOCK TABLES `pt_card` WRITE;
/*!40000 ALTER TABLE `pt_card` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_card` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_check`
--

DROP TABLE IF EXISTS `pt_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_check` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `name` varchar(64) NOT NULL COMMENT '产品名称',
  `cost` int(10) unsigned NOT NULL COMMENT '成本价格单位分',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '供货价格',
  `reward` int(11) NOT NULL DEFAULT '0' COMMENT '邀请人奖励',
  `unit` int(11) NOT NULL COMMENT '计费单位,0按次计费,其他按字数计费',
  `mini_price` int(10) unsigned NOT NULL COMMENT '限制最低售价单位分',
  `low_price` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '供应商规定的最低售价',
  `supplier_status` tinyint(4) NOT NULL COMMENT '供货方状态：1=正常，2=禁用，3=已删除',
  `status` tinyint(4) NOT NULL COMMENT '状态：1=正常，2=禁用',
  `config` varchar(512) DEFAULT '' COMMENT '配置信息JSON格式',
  `remark` varchar(256) DEFAULT NULL COMMENT '备注',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='检测产品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_check`
--

LOCK TABLES `pt_check` WRITE;
/*!40000 ALTER TABLE `pt_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_check_order`
--

DROP TABLE IF EXISTS `pt_check_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_check_order` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `tid` int(11) NOT NULL DEFAULT '0' COMMENT '推荐人ID',
  `original` varchar(400) DEFAULT NULL COMMENT '源文件路径',
  `product_id` varchar(64) DEFAULT NULL COMMENT '产品ID',
  `title` varchar(500) DEFAULT NULL COMMENT '文章标题',
  `author` varchar(200) DEFAULT NULL COMMENT '文章作者',
  `end_date` varchar(200) DEFAULT NULL COMMENT '发表日期',
  `school_id` varchar(64) DEFAULT NULL COMMENT '维普智评学校id',
  `class_code` varchar(64) DEFAULT NULL COMMENT '维普智评学科',
  `class_type` varchar(64) DEFAULT NULL COMMENT '维普智评类型',
  `cost` int(11) DEFAULT '0' COMMENT '代理成本单位分',
  `pcost` int(11) NOT NULL DEFAULT '0' COMMENT '平台成本 单位分',
  `unit_price` int(11) DEFAULT '0' COMMENT '单价',
  `total_price` int(11) DEFAULT '0' COMMENT '总价',
  `words` int(11) DEFAULT '0' COMMENT '字数',
  `piece` int(11) DEFAULT '0' COMMENT '件数',
  `ppiece` int(11) NOT NULL DEFAULT '0' COMMENT '平台件数',
  `profit` int(11) DEFAULT '0' COMMENT '利润',
  `pprofit` int(11) NOT NULL DEFAULT '0' COMMENT '平台利润',
  `tprofit` int(11) NOT NULL DEFAULT '0' COMMENT '推荐人利润',
  `copy_percent` varchar(200) DEFAULT NULL COMMENT '复制比',
  `lock` tinyint(4) DEFAULT '1' COMMENT '订单锁,1=正常,2=被锁住',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态 1=创建，2=解析成功，3=解析失败, 4=用户支付成功，5=供货成功，6=供货失败，7=检测失败 8=检测成功 9=已经退款,10已经删除',
  `payid` varchar(64) DEFAULT NULL COMMENT '支付ID',
  `spayid` varchar(64) DEFAULT NULL COMMENT '带掩码的支付ID',
  `pay_type` int(11) NOT NULL DEFAULT '0' COMMENT '支付方式:1微信支付,2支付宝,3卡支付,4API',
  `file_key` varchar(400) DEFAULT NULL,
  `report_url` varchar(1000) DEFAULT NULL COMMENT '报告下载地址',
  `remark` varchar(255) DEFAULT '' COMMENT '备注',
  `pay_time` datetime DEFAULT NULL COMMENT '付款时间',
  `lock_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '锁时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='检测记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_check_order`
--

LOCK TABLES `pt_check_order` WRITE;
/*!40000 ALTER TABLE `pt_check_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_check_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_config`
--

DROP TABLE IF EXISTS `pt_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_config` (
  `key` varchar(50) NOT NULL COMMENT '配置键名',
  `value` varchar(5000) DEFAULT NULL COMMENT '配置值',
  `title` varchar(100) NOT NULL COMMENT '配置名称',
  `type` varchar(20) DEFAULT 'text' COMMENT '配置类型',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_config`
--

LOCK TABLES `pt_config` WRITE;
/*!40000 ALTER TABLE `pt_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_email`
--

DROP TABLE IF EXISTS `pt_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_email` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `type_code` int(11) DEFAULT NULL COMMENT '业务类型:1验证码',
  `email` varchar(200) DEFAULT NULL COMMENT '接收方',
  `code` varchar(50) DEFAULT NULL COMMENT '验证码',
  `subject` varchar(60) DEFAULT NULL COMMENT '邮件主题',
  `body` mediumtext COMMENT '邮件内容',
  `attachment` varchar(1000) DEFAULT NULL COMMENT '附件可以是多个用;隔开',
  `status` int(11) DEFAULT '0' COMMENT '状态:0创建 1提交 2发送中 3成功 4提交失败 5发送失败',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮件发送记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_email`
--

LOCK TABLES `pt_email` WRITE;
/*!40000 ALTER TABLE `pt_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_notify`
--

DROP TABLE IF EXISTS `pt_notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_notify` (
  `order_id` varchar(64) NOT NULL COMMENT '订单ID',
  `userid` int(11) NOT NULL COMMENT '用户ID',
  `type` int(11) NOT NULL COMMENT '通知类型 1=解析结果 2=检测结果',
  `notify_url` varchar(400) DEFAULT NULL COMMENT '通知地址',
  `notify_num` int(11) DEFAULT NULL COMMENT '通知次数',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态：1=创建，2=成功，3=失败',
  `data` varchar(1000) DEFAULT '' COMMENT '通知数据',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`order_id`,`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='通知记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_notify`
--

LOCK TABLES `pt_notify` WRITE;
/*!40000 ALTER TABLE `pt_notify` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_notify` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_pay_record`
--

DROP TABLE IF EXISTS `pt_pay_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_pay_record` (
  `id` varchar(64) NOT NULL COMMENT 'out_trade_no',
  `orderid` varchar(64) DEFAULT NULL COMMENT '订单号',
  `method` varchar(50) DEFAULT NULL COMMENT '支付方式:wechat,alipay',
  `modeid` int(11) DEFAULT '0',
  `type` varchar(50) DEFAULT NULL COMMENT '支付类型:scan,jsapi,h5',
  `subject` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `price` float DEFAULT '0' COMMENT '价格',
  `status` int(11) DEFAULT NULL COMMENT '状态:0创建,1成功,2失败,3已经退款',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `tips` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_pay_record`
--

LOCK TABLES `pt_pay_record` WRITE;
/*!40000 ALTER TABLE `pt_pay_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_pay_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_paymode`
--

DROP TABLE IF EXISTS `pt_paymode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_paymode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT 'wxpay|alipay',
  `name` varchar(64) NOT NULL COMMENT '模版名称',
  `entype` varchar(64) DEFAULT NULL COMMENT '加密方式',
  `appid` varchar(200) DEFAULT NULL COMMENT 'APPID',
  `mchid` varchar(200) DEFAULT NULL COMMENT '微信商户ID',
  `mchkey` varchar(200) DEFAULT NULL COMMENT '微信APIV3秘钥',
  `mchsecretpath` varchar(400) DEFAULT NULL COMMENT '微信商户私钥路径',
  `mchpublicpath` varchar(400) DEFAULT NULL COMMENT '微信商户公钥路径',
  `appsecret` varchar(5000) DEFAULT NULL COMMENT '支付宝应用私钥',
  `apppublicpath` varchar(400) DEFAULT NULL COMMENT '支付宝应用公钥证书路径',
  `alipublicpath` varchar(400) DEFAULT NULL COMMENT '支付宝公钥证书路径',
  `alirootpath` varchar(400) DEFAULT NULL COMMENT '支付宝根证书路径',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付模版';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_paymode`
--

LOCK TABLES `pt_paymode` WRITE;
/*!40000 ALTER TABLE `pt_paymode` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_paymode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_payset`
--

DROP TABLE IF EXISTS `pt_payset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_payset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scene` varchar(50) DEFAULT NULL COMMENT '使用场景:pc,h5,wxh5',
  `type` varchar(50) DEFAULT NULL COMMENT '支付方式:wxpay,alipay',
  `modeid` int(11) DEFAULT '0' COMMENT '支付模板的id',
  `status` int(11) DEFAULT '0' COMMENT '状态:0禁用,1启用',
  `prefer` int(11) DEFAULT '0' COMMENT '是否默认支付:0否,1是',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='支付设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_payset`
--

LOCK TABLES `pt_payset` WRITE;
/*!40000 ALTER TABLE `pt_payset` DISABLE KEYS */;
INSERT INTO `pt_payset` VALUES (1,'pc','wxpay',0,0,0,'2026-06-14 21:16:18'),(2,'pc','alipay',0,0,0,'2026-06-14 21:16:18'),(3,'h5','alipay',0,0,0,'2026-06-14 21:16:18'),(4,'h5','wxpay',0,0,0,'2026-06-14 21:16:18'),(5,'wxh5','wxpay',0,0,0,'2026-06-14 21:16:18');
/*!40000 ALTER TABLE `pt_payset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_product_tips`
--

DROP TABLE IF EXISTS `pt_product_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_product_tips` (
  `product_id` varchar(64) NOT NULL COMMENT '产品id',
  `level` int(11) NOT NULL DEFAULT '0' COMMENT '级别:1信息 2警告 3错误',
  `content` varchar(300) NOT NULL COMMENT '内容',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='产品提示信息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_product_tips`
--

LOCK TABLES `pt_product_tips` WRITE;
/*!40000 ALTER TABLE `pt_product_tips` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_product_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_sms`
--

DROP TABLE IF EXISTS `pt_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_sms` (
  `id` varchar(50) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL COMMENT '用户id',
  `type_code` int(11) DEFAULT NULL COMMENT '业务类型:1验证码',
  `code` varchar(50) DEFAULT NULL COMMENT '验证码',
  `phone` varchar(50) DEFAULT NULL COMMENT '手机号',
  `sign_id` varchar(50) DEFAULT NULL COMMENT '签名id',
  `template_id` varchar(50) DEFAULT NULL COMMENT '模板id',
  `params` varchar(200) DEFAULT NULL COMMENT '参数',
  `sms_id` varchar(50) DEFAULT NULL COMMENT '运营方返回的id',
  `status` int(11) DEFAULT '0' COMMENT '状态:0创建 1提交 2发送中 3成功 4提交失败 5发送失败',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='短信发送记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_sms`
--

LOCK TABLES `pt_sms` WRITE;
/*!40000 ALTER TABLE `pt_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_special_price`
--

DROP TABLE IF EXISTS `pt_special_price`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_special_price` (
  `productid` varchar(64) NOT NULL COMMENT '产品id',
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '价格单位分',
  `remark` varchar(256) DEFAULT NULL,
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='特殊价格';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_special_price`
--

LOCK TABLES `pt_special_price` WRITE;
/*!40000 ALTER TABLE `pt_special_price` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_special_price` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_user`
--

DROP TABLE IF EXISTS `pt_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tid` int(10) unsigned DEFAULT '0' COMMENT '推荐人ID',
  `name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `email` varchar(150) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `avatar` varchar(300) DEFAULT NULL COMMENT '用户头像',
  `pass` varchar(100) NOT NULL,
  `pay_type` varchar(512) DEFAULT NULL COMMENT '支持的支付方式，用,号分割',
  `wxpay` int(11) NOT NULL DEFAULT '0' COMMENT '微信支付模板,默认用平台模板',
  `alipay` int(11) NOT NULL DEFAULT '0' COMMENT '支付宝模板默认用平台模板',
  `apikey` varchar(100) DEFAULT NULL,
  `cardkey` varchar(64) DEFAULT NULL COMMENT '检测卡API密钥',
  `api_status` int(11) DEFAULT '1' COMMENT '1允许,0不允许',
  `ip_list` varchar(200) DEFAULT NULL COMMENT '白名单用,隔开',
  `openid` varchar(128) DEFAULT NULL COMMENT '微信公众号',
  `alarm_threshold` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '告警阀值单位分',
  `alarm_method` varchar(256) DEFAULT NULL COMMENT '告警方式用,分割',
  `status` tinyint(3) unsigned DEFAULT '1' COMMENT '0待激活,1正常,2冻结',
  `regtime` datetime DEFAULT NULL COMMENT '注册时间',
  `logintime` datetime DEFAULT NULL COMMENT '登录时间',
  `balance` int(11) DEFAULT '0' COMMENT '余额',
  `money` int(11) NOT NULL DEFAULT '0' COMMENT '分销的总收入',
  `tmoney` int(11) NOT NULL DEFAULT '0' COMMENT '为邀请人贡献',
  `account_type` varchar(256) DEFAULT NULL COMMENT '默认收款类型',
  `account` varchar(256) DEFAULT NULL COMMENT '默认收款账户',
  `points` int(11) NOT NULL DEFAULT '0' COMMENT '积分等同于人民币分',
  `status_time` datetime DEFAULT NULL,
  `tips` varchar(256) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_user`
--

LOCK TABLES `pt_user` WRITE;
/*!40000 ALTER TABLE `pt_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_user_check`
--

DROP TABLE IF EXISTS `pt_user_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_user_check` (
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `product_id` varchar(64) NOT NULL COMMENT '产品id',
  `unit` int(11) NOT NULL DEFAULT '0' COMMENT '计费单位,0按次计费,其他按字数计费',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '单价',
  `name` varchar(64) DEFAULT NULL COMMENT '产品名称',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态:1正常 2禁用',
  PRIMARY KEY (`userid`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户产品设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_user_check`
--

LOCK TABLES `pt_user_check` WRITE;
/*!40000 ALTER TABLE `pt_user_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_user_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_user_notice`
--

DROP TABLE IF EXISTS `pt_user_notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_user_notice` (
  `userid` int(11) NOT NULL COMMENT '用户id',
  `position` varchar(64) NOT NULL COMMENT '位置',
  `conent` varchar(300) DEFAULT NULL COMMENT '内容',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态:1待审核 2审核通过 3审核被拒',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`userid`,`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户公告';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_user_notice`
--

LOCK TABLES `pt_user_notice` WRITE;
/*!40000 ALTER TABLE `pt_user_notice` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_user_notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_web_set`
--

DROP TABLE IF EXISTS `pt_web_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_web_set` (
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `webid` varchar(126) NOT NULL COMMENT '网站id',
  `show_jc` int(11) NOT NULL DEFAULT '0' COMMENT '展示加盟',
  `qq` varchar(126) DEFAULT NULL COMMENT 'QQ联系方式',
  `wechat` varchar(126) DEFAULT NULL COMMENT '微信联系方式',
  `phone` varchar(126) DEFAULT NULL COMMENT '电话联系方式',
  `pay_type` varchar(300) DEFAULT NULL COMMENT '支持的支付方式',
  `tid_name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `index_id` (`webid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='网站设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_web_set`
--

LOCK TABLES `pt_web_set` WRITE;
/*!40000 ALTER TABLE `pt_web_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_web_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_withdraw`
--

DROP TABLE IF EXISTS `pt_withdraw`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_withdraw` (
  `id` varchar(64) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0' COMMENT '用户id',
  `name` varchar(64) NOT NULL COMMENT '用户姓名',
  `money` int(11) NOT NULL DEFAULT '0' COMMENT '提现金额,分',
  `account_type` varchar(64) DEFAULT NULL COMMENT '账户类型',
  `account` varchar(64) DEFAULT NULL COMMENT '账号',
  `do_time` datetime DEFAULT NULL COMMENT '处理时间',
  `amount` int(11) NOT NULL DEFAULT '0' COMMENT '实际到账,分',
  `charge` int(11) NOT NULL DEFAULT '0' COMMENT '手续费,分',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '状态:1待处理,2成功,失败',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `remark` varchar(256) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提现记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_withdraw`
--

LOCK TABLES `pt_withdraw` WRITE;
/*!40000 ALTER TABLE `pt_withdraw` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_withdraw` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'beifen'
--

--
-- Dumping routines for database 'beifen'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-03 18:46:22
