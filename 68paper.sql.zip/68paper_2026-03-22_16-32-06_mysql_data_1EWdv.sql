-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: 68paper
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `pt_admin`
--

DROP TABLE IF EXISTS `pt_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL COMMENT '昵称',
  `email` varchar(60) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `avatar` varchar(100) DEFAULT NULL COMMENT '用户头像',
  `pass` varchar(100) NOT NULL,
  `openid` varchar(128) DEFAULT NULL COMMENT '微信公众号',
  `status` tinyint(3) unsigned DEFAULT '1' COMMENT '0待激活,1正常,2冻结',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `tips` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_admin`
--

LOCK TABLES `pt_admin` WRITE;
/*!40000 ALTER TABLE `pt_admin` DISABLE KEYS */;
INSERT INTO `pt_admin` VALUES (1,'admin',NULL,NULL,'/static/images/avatar/admin-1.png','e10adc3949ba59abbe56e057f20f883e',NULL,1,NULL,NULL,NULL);
/*!40000 ALTER TABLE `pt_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_check`
--

DROP TABLE IF EXISTS `pt_check`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_check` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `name` varchar(64) NOT NULL COMMENT '产品名称',
  `cost` int(10) unsigned NOT NULL COMMENT '成本价格单位分',
  `unit` int(11) NOT NULL COMMENT '计费单位,0按次计费,其他按字数计费',
  `mini_price` int(10) unsigned NOT NULL COMMENT '限制最低售价单位分',
  `supplier_status` tinyint(4) NOT NULL COMMENT '供货方状态：1=正常，2=禁用，3=已删除',
  `status` tinyint(4) NOT NULL COMMENT '状态：1=正常，2=禁用',
  `config` varchar(512) DEFAULT '' COMMENT '配置信息JSON格式',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='检测产品';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_check`
--

LOCK TABLES `pt_check` WRITE;
/*!40000 ALTER TABLE `pt_check` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_check` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_check_order`
--

DROP TABLE IF EXISTS `pt_check_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_check_order` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `shopid` varchar(64) NOT NULL COMMENT '店铺ID',
  `original` varchar(400) DEFAULT NULL COMMENT '源文件路径',
  `product_id` varchar(64) DEFAULT NULL COMMENT '产品ID',
  `title` varchar(500) DEFAULT NULL COMMENT '文章标题',
  `author` varchar(200) DEFAULT NULL COMMENT '文章作者',
  `end_date` varchar(200) DEFAULT NULL COMMENT '发表日期',
  `cost` int(11) DEFAULT '0' COMMENT '成本单位分',
  `unit_price` int(11) DEFAULT '0' COMMENT '单价',
  `total_price` int(11) DEFAULT '0' COMMENT '总价',
  `words` int(11) DEFAULT '0' COMMENT '字数',
  `piece` int(11) DEFAULT '0' COMMENT '件数',
  `profit` int(11) DEFAULT '0' COMMENT '利润',
  `copy_percent` varchar(200) DEFAULT NULL COMMENT '复制比',
  `lock` tinyint(4) DEFAULT '1' COMMENT '订单锁,1=正常,2=被锁住',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态 1=创建，2=解析成功，3=解析失败, 4=用户支付成功，5=供货成功，6=供货失败，7=检测失败 8=检测成功 9=已经退款,10已经删除',
  `payid` varchar(64) DEFAULT NULL COMMENT '支付ID',
  `file_key` varchar(400) DEFAULT NULL,
  `report_url` varchar(1000) DEFAULT NULL COMMENT '报告下载地址',
  `remark` varchar(255) DEFAULT '' COMMENT '备注',
  `lock_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '锁时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='检测记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_check_order`
--

LOCK TABLES `pt_check_order` WRITE;
/*!40000 ALTER TABLE `pt_check_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_check_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_config`
--

DROP TABLE IF EXISTS `pt_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_config` (
  `key` varchar(50) NOT NULL COMMENT '配置键名',
  `value` varchar(5000) DEFAULT NULL COMMENT '配置值',
  `title` varchar(100) NOT NULL COMMENT '配置名称',
  `type` varchar(20) DEFAULT 'text' COMMENT '配置类型',
  `updated_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_config`
--

LOCK TABLES `pt_config` WRITE;
/*!40000 ALTER TABLE `pt_config` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_pay_record`
--

DROP TABLE IF EXISTS `pt_pay_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_pay_record` (
  `id` varchar(64) NOT NULL COMMENT 'out_trade_no',
  `orderid` varchar(64) DEFAULT NULL COMMENT '订单号',
  `method` varchar(50) DEFAULT NULL COMMENT '支付方式:wechat,alipay',
  `modeid` int(11) DEFAULT '0',
  `type` varchar(50) DEFAULT NULL COMMENT '支付类型:scan,jsapi,h5',
  `subject` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `price` float DEFAULT '0' COMMENT '价格',
  `status` int(11) DEFAULT NULL COMMENT '状态:0创建,1成功,2失败,3已经退款',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `tips` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='支付记录';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_pay_record`
--

LOCK TABLES `pt_pay_record` WRITE;
/*!40000 ALTER TABLE `pt_pay_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_pay_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_paymode`
--

DROP TABLE IF EXISTS `pt_paymode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_paymode` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT 'wxpay|alipay',
  `name` varchar(64) NOT NULL COMMENT '模版名称',
  `entype` varchar(64) DEFAULT NULL COMMENT '加密方式',
  `appid` varchar(200) DEFAULT NULL COMMENT 'APPID',
  `mchid` varchar(200) DEFAULT NULL COMMENT '微信商户ID',
  `mchkey` varchar(200) DEFAULT NULL COMMENT '微信APIV3秘钥',
  `mchsecretpath` varchar(400) DEFAULT NULL COMMENT '微信商户私钥路径',
  `mchpublicpath` varchar(400) DEFAULT NULL COMMENT '微信商户公钥路径',
  `appsecret` varchar(5000) DEFAULT NULL COMMENT '支付宝应用私钥',
  `apppublicpath` varchar(400) DEFAULT NULL COMMENT '支付宝应用公钥证书路径',
  `alipublicpath` varchar(400) DEFAULT NULL COMMENT '支付宝公钥证书路径',
  `alirootpath` varchar(400) DEFAULT NULL COMMENT '支付宝根证书路径',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='支付模版';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_paymode`
--

LOCK TABLES `pt_paymode` WRITE;
/*!40000 ALTER TABLE `pt_paymode` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_paymode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_payset`
--

DROP TABLE IF EXISTS `pt_payset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_payset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scene` varchar(50) DEFAULT NULL COMMENT '使用场景:pc,h5,wxh5',
  `type` varchar(50) DEFAULT NULL COMMENT '支付方式:wxpay,alipay',
  `modeid` int(11) DEFAULT '0' COMMENT '支付模板的id',
  `status` int(11) DEFAULT '0' COMMENT '状态:0禁用,1启用',
  `prefer` int(11) DEFAULT '0' COMMENT '是否默认支付:0否,1是',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='支付设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_payset`
--

LOCK TABLES `pt_payset` WRITE;
/*!40000 ALTER TABLE `pt_payset` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_payset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_shop`
--

DROP TABLE IF EXISTS `pt_shop`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_shop` (
  `id` varchar(64) NOT NULL COMMENT '主键ID',
  `name` varchar(64) NOT NULL COMMENT '店铺名称',
  `status` tinyint(4) NOT NULL COMMENT '状态：1=正常，2=禁用',
  `file_name` varchar(200) DEFAULT '' COMMENT '附件文件名',
  `file_path` varchar(200) DEFAULT '' COMMENT '附件路径',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '修改时间',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='店铺';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_shop`
--

LOCK TABLES `pt_shop` WRITE;
/*!40000 ALTER TABLE `pt_shop` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_shop` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pt_shop_product`
--

DROP TABLE IF EXISTS `pt_shop_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pt_shop_product` (
  `shopid` varchar(64) NOT NULL COMMENT '店铺id',
  `productid` varchar(64) NOT NULL COMMENT '产品id',
  `unit` int(11) DEFAULT NULL COMMENT '计费单位,0按次计费,其他按字数计费',
  `price` int(11) DEFAULT NULL COMMENT '单价(分)',
  `status` tinyint(4) DEFAULT NULL COMMENT '状态：1=正常，2=禁用',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `tips` varchar(200) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`shopid`,`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pt_shop_product`
--

LOCK TABLES `pt_shop_product` WRITE;
/*!40000 ALTER TABLE `pt_shop_product` DISABLE KEYS */;
/*!40000 ALTER TABLE `pt_shop_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database '68paper'
--

--
-- Dumping routines for database '68paper'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-22 16:32:06
